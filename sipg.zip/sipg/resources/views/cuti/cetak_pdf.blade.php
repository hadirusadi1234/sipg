<!DOCTYPE html>
<html>
<head>
    <title>Laporan</title>
    <style type="text/css">
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            text-align: left;
            padding: 8px;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Laporan</h1>
    <table>
        <tr>
            <th>Staff</th>
            <td>{{ $staff->nama }}</td>
        </tr>
        <tr>
            <th>Tanggal Mulai</th>
            <td>{{ $tgl_mulai }}</td>
        </tr>
        <tr>
            <th>Tanggal Selesai</th>
            <td>{{ $tgl_selesai }}</td>
        </tr>
        <tr>
            <th>Durasi</th>
            <td>{{ $durasi }}</td>
        </tr>
        <tr>
            <th>Keterangan</th>
            <td>{{ $keterangan }}</td>
        </tr>
        <tr>
            <th>Status</th>
            <td>{{ $status }}</td>
        </tr>
    </table>
</body>
</html>
