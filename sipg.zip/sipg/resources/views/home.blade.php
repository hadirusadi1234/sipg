@extends('layouts.app')
@section('content')
	<div class="content-wrapper pb-5 pt-3">
		<section class="content pb-3">
			<div class="container-fluid">
				<div class="row">
					<div class="col-12">
						<div class="row">
							<div class="col-md-4 col-sm-4 col-12">
								<div class="info-box bg-info-gradient">
									<span class="info-box-icon"><i class="fa fa-money"></i></span>
									<div class="info-box-content">
										<span class="info-box-text">Salary</span>
										<span class="info-box-number">{{ $salary ?? 0 }}</span>
									</div>
								</div>
							</div>
							<div class="col-md-4 col-sm-4 col-12">
								<div class="info-box bg-success-gradient">
									<span class="info-box-icon"><i class="fa fa-calendar"></i></span>
		
									<div class="info-box-content">
										<span class="info-box-text">Schedule</span>
										<span class="info-box-number">{{ $schedule ?? 0 }}</span>
									</div>
								</div>
							</div>
							<div class="col-md-4 col-sm-4 col-12">
								<div class="info-box bg-secondary-gradient">
									<span class="info-box-icon"><i class="fa fa-user-circle"></i></span>
									<div class="info-box-content">
										<span class="info-box-text">Pegawai</span>
										<span class="info-box-number">{{ $staff ?? 0 }}</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
                <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    </head>
    
    <body>
        <br>
            <div class="container">
            <div class="text-center">
                <h2>Kantor Dinas Lingkungan Hidup</h2>
            </div>
            <div class="row">
                <div class="col-sm">
                    <div class="card">
                        <div class="card-header">
                            <img src="img/dlh.jpg" width="500" height="500"
                                class="card-img-top" alt="...">
                        </div>
                        <div class="card-body">
                            <h5 class="card-title"><center>VISI</center></h5>
                            <p class="card-text"><center>“TERWUJUDNYA PEMBANGUNAN YANG BERKELANJUTAN DAN BERWAWASAN LINGKUNGAN HIDUP MENUJU BANJARMASIN BERSIH, INDAH DAN NYAMAN”</center></p>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title"><center>MISI</center></h5>
                            <p class="card-text">1.	Mencegah, mengendalikan dan pemulihan pencemaran air, udara dan tanah serta mendukung terpeliharanya kelestarian fungsi lingkungan hidup.
                            <p>2.	Mengembangkan sistem data dan informasi kondisi lingkungan hidup.</p>
                            <p>3.	Menciptakan kota Banjarmasin yang bersih, indah, dan nyaman serta terbangunnya taman-taman kota dan ruang terbuka hijau.</p>
                            4.	Pengembangan kapasitas sumber dayamanusia manusia yang berwawasan lingkungan.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
				<hr>
				<div class="row">
					<div class="col-md-10 offset-md-1">
						<div class="col-md-5 col-sm-12 col-12 mb-3 float-left">
							<div class="text-center">Jumlah Pegawai berdasarkan Departement</div>
							<canvas id="BarChartStaffDepartement" width="200" height="200"></canvas>
						</div>
						<div class="col-md-5 col-sm-12 col-12 mb-3 float-right">
							<div class="text-center">Jumlah Pegawai berdasarkan Position</div>
							<canvas id="BarChartStaffPosition" width="200" height="200"></canvas>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>

@endsection
@section('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.3/dist/Chart.min.js"></script>
<script>
	$('.alert').fadeOut(7000);
    var bar_staff_departement = document.getElementById('BarChartStaffDepartement').getContext('2d');
    var bar_staff_position = document.getElementById('BarChartStaffPosition').getContext('2d');
    
    // Statistik Staff Departement

    var Departement = [];
    var CountDepartement = [];
    $.get("{{ url('/home/getStaffDepartement')}}", function(data){

        $.each(data, function(i,item){
            Departement.push(item.name_departement);
            CountDepartement.push(item.count);
        });

        var myChart = new Chart(bar_staff_departement, 
        {
            type: 'bar',
            data: {
                labels: Departement,
                datasets: [{
                    label: 'Jumlah Pegawai',
                    data: CountDepartement,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    });

    // Statistik Staff Position

    var Position = [];
    var CountPosition = [];
    $.get("{{ url('/home/getStaffPosition')}}", function(data){
        $.each(data, function(i,item){
            Position.push(item.name_position);
            CountPosition.push(item.count);
        });
    
        var myChart = new Chart(bar_staff_position, {

            type: 'bar',
            data: {
                labels: Position,
                datasets: [{
                    label: 'Jumlah Pegawai',
                    data: CountPosition,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    });
</script>
@endsection