Aplikasi Sistem Informasi Pendataan dan Gaji Karyawan Menggunakan Framework Laravel 7.*

Created By : [Tasrin Adiputra](https://www.facebook.com/tasrinteknik)

Untuk menjalankan Aplikasi ini silahkan jalankan perintah berikut pada command promt / CMD / Git CMD anda

##Usage

- Run `git clean  -d  -fx .`
- Run `composer install`
- Run `copy .env.example .env`
- Run `php artisan key:generate`
- Create database for this app and onfig the ` .env ` file
- Run `php artisan migrate`
- Run `php artisan db:seed`
- Run `php artisan storage:links`
- Run `php artisan serve`
- Done. :)