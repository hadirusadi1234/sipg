<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Dompdf\Dompdf;
class CetakPDFController extends Controller
{
    public function cetakPDF(Request $request)
    {
        $staff = Staff::find($request->id);
        $tgl_mulai = $request->tgl_mulai;
        $tgl_selesai = $request->tgl_selesai;
        $durasi = $request->durasi;
        $keterangan = $request->keterangan;
        $status = $request->status;

        $pdf = PDF::loadView('cetak_pdf', compact('staff', 'tgl_mulai', 'tgl_selesai', 'durasi', 'keterangan', 'status'));

        return $pdf->download('laporan.pdf');
    }
    
    //
}
