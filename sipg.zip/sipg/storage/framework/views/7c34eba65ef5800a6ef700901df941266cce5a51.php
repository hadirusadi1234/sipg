<nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
            <?php if(auth()->guard()->guest()): ?>
            <?php echo e(config('app.name', 'Laravel')); ?>

            <?php else: ?>
            <span style="font-size: 14px"><?php echo e(Auth::user()->role->display_name ?? ''); ?></span>
            <?php endif; ?>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php if($sub == 'beranda'): ?> <?php echo e('active'); ?> <?php endif; ?>" href="#"><i class="fa fa-home"></i> Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if($sub == 'faq'): ?> <?php echo e('active'); ?> <?php endif; ?>" href="#"><i class="fa fa-question-circle-o"></i> FAQ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if($sub == 'about'): ?> <?php echo e('active'); ?> <?php endif; ?>" href="#"><i class="fa fa-info"></i> Tentang Kami</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle <?php if($page == 'login' || $page == 'registrasi'): ?> <?php echo e('active'); ?> <?php endif; ?>" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <i class="fa fa-lock"></i> Masuk / Daftar <span class="caret"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" href="<?php echo e(route('login')); ?>">
                                <i class="fa fa-unlock mr-1"></i> Login
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#">
                                <i class="fa fa-sign-in mr-1"></i> Registrasi
                            </a>
                        </div>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav><?php /**PATH D:\sipg\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>