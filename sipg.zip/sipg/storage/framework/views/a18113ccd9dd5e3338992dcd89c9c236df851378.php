<aside class="main-sidebar sidebar-light-danger elevation-4">
    <a href="<?php echo e(route('home')); ?>" class="brand-link bg-danger">
        <img src="<?php echo e(asset('img/dlhbjm.png')); ?>" alt="Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light"><?php echo e(('SIPG')); ?></span>
    </a>

    <div class="sidebar">
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="<?php echo e(asset(Auth::user()->staff->photo ?? 'img/user.jpg')); ?>" class="img-circle elevation-2" alt="User Image" style="width: 35px; height: 35px;">
            </div>
            <div class="info">
                <a href="#" class="d-block"><?php echo e(ucwords(Auth::user()->staff->name ?? Auth::user()->name)); ?></a>
            </div>
        </div>

        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="<?php echo e(route('home')); ?>" class="nav-link <?php echo e($page == 'home'|| $page == '' ? 'active' : ''); ?>">
                    <i class="nav-icon fa fa-tachometer"></i>
                        <p>
                            Dashboard
                        </p>
                    </a>
                </li>
                <?php if(!Auth::user()->hasRole('karyawan')): ?>
                <li class="nav-item has-treeview <?php echo e($page == 'master' ? 'menu-open' : ''); ?>">
                    <a href="#" class="nav-link <?php echo e($page == 'master' ? 'active' : ''); ?>">
                        <i class="nav-icon fa fa-laptop"></i>
                        <p>
                            Master
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('master.position.index')); ?>" class="nav-link <?php echo e($sub == 'position' ? 'active' : ''); ?>">
                                <i class="nav-icon fa fa-circle-o"></i>
                                <p>Position</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('master.departement.index')); ?>" class="nav-link <?php echo e($sub == 'departement' ? 'active' : ''); ?>">
                                <i class="nav-icon fa fa-circle-o"></i>
                                <p>Departement</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('master.staff.index')); ?>" class="nav-link <?php echo e($sub == 'staff' ? 'active' : ''); ?>">
                                <i class="nav-icon fa fa-circle-o"></i>
                                <p>Staff</p>
                            </a>
                        </li>
                    </ul>
                </li>
               
                
                <?php endif; ?>

                <li class="nav-item">
                    <a href="<?php echo e(route('schedule.index')); ?>" class="nav-link <?php echo e($page == 'schedule' ? 'active' : ''); ?>">
                        <i class="nav-icon fa fa-calendar"></i>
                        <p>Schedule</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('cuti.index')); ?>" class="nav-link <?php echo e($page == 'cuti' ? 'active' : ''); ?>">
                        <i class="nav-icon fa fa-calendar"></i>
                        <p>Permohonan Cuti</p>
                    </a>
                </li>
                <?php if(Auth::user()->hasRole('admin')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('salary.index')); ?>" class="nav-link <?php echo e($page == 'salary' ? 'active' : ''); ?>">
                            <i class="nav-icon fa fa-money"></i>
                            <p>Penggajian</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('salary.index')); ?>" class="nav-link <?php echo e($page == '' ? 'active' : ''); ?>">
                            <i class="nav-icon fa fa-money"></i>
                            <p>Tunjangan</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('absensi.index')); ?>" class="nav-link <?php echo e($page == 'absensi' ? 'active' : ''); ?>">
                            <i class="nav-icon fa fa-laptop"></i>
                            <p>Absensi</p>
                        </a>
                    </li>
               
                    <li class="nav-header">Special Menu</li>
                    
                    <li class="nav-item">
                        <a href="<?php echo e(route('users.index')); ?>" class="nav-link <?php echo e($page == 'users' ? 'active' : ''); ?>">
                            <i class="nav-icon fa fa-user-circle-o"></i>
                            <p>Users</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('roles.index')); ?>" class="nav-link <?php echo e($page == 'roles' ? 'active' : ''); ?>">
                            <i class="nav-icon fa fa-cog"></i>
                            <p>Role</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="nav-link">
                            <i class="nav-icon fa fa-sign-out"></i>
                            <p>Logout</p>
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</aside><?php /**PATH D:\sipg\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>