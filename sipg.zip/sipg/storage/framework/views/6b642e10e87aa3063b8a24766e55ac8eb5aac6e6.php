
<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.0.6-rc.1/dist/css/select2.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper pb-3">
        <div class="content pb-5 pt-3">
              <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-light">
                                <h3 class="card-title back-top" style="margin-top: 5px;">
                                    <a href="<?php echo e(route('absensi.index')); ?>" title="Kembali" data-toggle="tooltip" data-placement="right" class="btn text-muted">
                                        <i class="fa fa-arrow-left fa-fw"></i></span>
                                    </a>
                                </h3>
                                <div class="float-left offset-5 pt-1">
                                    <span class="d-none d-md-block d-lg-block">DAFTAR ABSENSI</span>
                                </div>
                                <div class="float-right row">
                                    <form action="<?php echo e(url()->current()); ?>">
                                        <div class="input-group">
                                            <select name="filter" class="form-control input-sm select2">
                                                <option value="">Tampilkan semua</option>
                                                <?php if(!empty($filter)): ?>
                                                    <option value="all">SHOW ALL</option>
                                                <?php endif; ?>
                                                <?php $__currentLoopData = $departement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->name); ?>" <?php echo e($item->name == old('filter', $filter) ? 'selected':''); ?>><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <div class="input-group-append">
                                                <button type="submit" class="btn btn-secondary btn-sm">Filter</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div> 
                            <div class="container-fluid row p-2" style="font-size: 14px;">
                                <div class="col-md-9 p-0">
                                    <table class="table no-border header-table mb-0" style="white-space: normal;">
                                        <tr style="line-height: 1px;">
                                            <td style="width: 100px;">Periode</td>
                                            <td style="width: 5px;">:</td>
                                            <td><?php echo e(str_replace('-', ' - ', ucwords($absensi->periode))); ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <div class="card-body p-0">
                                    <table class="table table-bordered mb-0" style="font-size: 14px;">
                                        <tbody>
                                            <tr class="text-center bg-light" style="font-weight: bold;line-height: 1;">
                                                <td colspan="4" style="vertical-align : middle;width: 10px;">KEAHLIAN</td>
                                                <?php if(count($attendance_date) > 0): ?>
                                                    <td colspan="<?php echo e(count($attendance_date)); ?>" style="vertical-align : middle;white-space:normal;
                                                    width: auto;
                                                    height: auto;
                                                    word-wrap: break-word;">TANGGAL ABSEN</td>
                                                <?php endif; ?>
                                                <td rowspan="2" style="vertical-align : middle; white-space: normal; width:50px; text-align: center;">TOTAL</td>
                                            </tr>
                                            <tr class="text-center bg-light" style="line-height: 0.2;">
                                                <td style="width:5px;">NO.</td>
                                                <td>Nama</td>
                                                <td>Status</td>
                                                <td>Departement</td>
                                                
                                                <?php $__currentLoopData = $attendance_date; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td class="count_date_absen" style="width:20px; vertical-align: middle; text-align: center;"><?php echo e(date('d', strtotime($d->tanggal_absen))); ?></td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                                <?php
                                                    $grand_total = 0;
                                                ?>
    
                                                <?php $__empty_1 = true; $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr style="line-height: 0.2;">
                                                    <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($schedule->staff->name); ?></td>
                                                    <td class="text-center">
                                                        <span class="badge <?php echo e($schedule->staff->position->status == 'Staff' ? 'badge-info' : 'badge-secondary'); ?>"><?php echo e($schedule->staff->position->status ?? ''); ?></span>
                                                    </td>
                                                    <td class="text-center"><?php echo e($schedule->staff->departement->name); ?></td>
                                                    <?php
                                                        $sum_kehadiran = 0;
                                                        $count_absen_staff = $schedule->absensi->where('periode', $absensi->periode)->count();
                                                    ?>
                                                    
                                                    <?php $__currentLoopData = $schedule->absensi->where('periode', $absensi->periode); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($loop->first): ?>
                                                            <?php if(count($attendance_date) != $count_absen_staff): ?>
                                                                <td colspan="<?php echo e(intval(count($attendance_date)) - intval($count_absen_staff)); ?>"><hr class="p-0 m-0 label-danger"></td>
                                                            <?php endif; ?> 
                                                        <?php endif; ?>
    
                                                        <?php if($item->attendance_id != ''): ?>     
                                                            <td class="text-center">
                                                                <?php echo '<span class="'.$item->attendance->label.'">'.$item->attendance->singkatan.'</span>'; ?>

                                                            </td>
                                                        <?php else: ?>
                                                            <td class="text-center" style="width:20px;"><i class="fa fa-remove text-danger" style="line-height: 0.2;"></i></td>
                                                        <?php endif; ?>
                                                        <?php
                                                            $sum_kehadiran +=  $item->attendance->value;
                                                        ?>
    
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($count_absen_staff == 0): ?>
                                                        <td class="not_absen text-center">-</td>
                                                    <?php endif; ?>
                                                    <td style="vertical-align: middle; text-align: center;"><?php echo e($sum_kehadiran); ?></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <td class="text-center" colspan="<?php echo e(4 + count($attendance_date) + 7); ?>">Tidak ada data</td>
                                                <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="card-footer p-2">
                                <div class="text-right">
                                    <?php if(!empty($filter)): ?>
                                        <a href="<?php echo e(route('absensi.export.excel', [$absensi->periode, $filter])); ?>" class="btn btn-success btn-sm" id="export-excel">
                                            <i class="fa fa-file-excel-o fa-fw"></i> Export Excel
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('absensi.export.excel', [$absensi->periode, 'all'])); ?>" class="btn btn-success btn-sm" id="export-excel">
                                            <i class="fa fa-file-excel-o fa-fw"></i> Export Excel
                                        </a>
                                    <?php endif; ?>
                                </div>
                                <br>
                                <div class="text-right">
                                    <?php if(!empty($filter)): ?>
                                        <a href="<?php echo e(route('absensi.export.excel', [$absensi->periode, $filter])); ?>" class="btn btn-danger btn-sm" id="export-excel">
                                            <i class="fa fa-file-excel-o fa-fw"></i> Export Excel
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('absensi.export.excel', [$absensi->periode, 'all'])); ?>" class="btn btn-danger btn-sm" id="export-excel">
                                            <i class="fa fa-file-excel-o fa-fw"></i> Export Excel
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div id="loading"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.6-rc.1/dist/js/select2.min.js"></script>
    <script>
        $('.select2').select2({
			placeholder : 'Filter Data..'
        });
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();
        });

        $('#export-excel').on("click", function () {
            $(this).addClass('disabled');
            setTimeout(RemoveClass, 1000);
        });

        function RemoveClass() {
            $('#export-excel').removeClass("disabled");
		}

        var count = $(".count_date_absen").length
        $(".not_absen").attr("colspan", count);
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipg\resources\views/absensi/detail/show.blade.php ENDPATH**/ ?>