<div class="card-body pt-0 pl-1 pr-1 pb-0">
        
    <?php if(empty($staff)): ?>
        <div class="alert alert-warning text-justify">
            <strong>Warning !!</strong> Data staff belum ada, anda tidak dapat melakukan absensi. Silahkan input data staff terlebih dulu 
            <a class="float-right" href="<?php echo e(route('salary.index')); ?>" data-toggle="tooltip" title="Silahkan klik untuk menginput data pekerja" style="text-decoration-color: blue;">
                <span class="text-primary">Input Sekarang ?</span>  
            </a>
        </div>
    <?php endif; ?>
    
    <div class="container-fluid row p-2" style="font-size: 14px;">
        <div class="col-md-9 p-0">
            <table class="table no-border header-table mb-0 mt-0" style="">
                <tr style="line-height: 1px;">
                    <td width="100">Karyawan Status</td>
                    <td width="10">:</td>
                    <td class="text-left">
                        <span class="badge <?php echo e($request->status == 'Staff' ? 'badge-info' : 'badge-secondary'); ?>"><?php echo e($request->status ?? ''); ?></span>
                    </td>
                </tr>
                <tr style="line-height: 1px;">
                    <td width="100">Periode</td>
                    <td width="10">:</td>
                    <td class="text-left"><?php echo e($request->periode); ?></td>
                </tr>
            </table>
        </div>
    </div>
    <div class="table-responsive pl-2 pr-2">
        <table class='table table-striped table-bordered'>
            
                <tr>
                    <td>
                        <label class="text-bold"><?php echo e($request->status); ?></label><br>
                        <select name="staff_id" class="form-control select2" required>
                            <option value=""></option>
                            <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $position->staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['staff_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('staff_id')); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td colspan="2">
                        <label class="font-weight-bold">Tanggal Gaji</label><br>
                        <input type="text" name="tgl_salary" class="form-control datepicker <?php $__errorArgs = ['tgl_salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="01/31/2020" autocomplete="off" onkeypress="return false">
                        <?php $__errorArgs = ['tgl_salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('tgl_salary')); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>

                <tbody id="KaryawanHarian" style="display: none">
                <tr class="bg-white">
                    <td>Total Kehadiran <div class="text-right"></td>
                        <td class="text-right">
                            <input type="hidden" name="total_kehadiran" class="form-control" readonly>
                            <span id="total_kehadiran" class="badge badge-success">0</span> Hari
                        </td>
                    <td class="text-right"><span id="salary_preview">Rp. 0</span></td>
                </tr>
                </tbody>

                <tr class="bg-white">
                    <td>Salary <?php echo e($request->status == 'Staff' ? 'Bulanan' : 'Harian'); ?></td>
                    <td colspan="2" class="text-right">
                        <input type="hidden" name="salary" class="form-control" id="total_salary_hidden" value="0" readonly>
                        <?php echo e($request->status == 'Staff' ? '' : 'Total : '); ?> <span id="total_salary">Rp. 0</span>
                    </td>
                </tr>

                <tbody id="KaryawanBulanan">
                <tr>
                    <td>Pot BPJS</td>
                    <td style="min-width: 180px;">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Rp</span>
                            </div>
                            <input type="text" name="pot_bpjs" class="form-control <?php $__errorArgs = ['pot_bpjs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pot_bpjs" value="0" placeholder="0" onkeypress="return hanyaAngka(this)" maxlength="8" autocomplete="off">
                        </div>
                        <?php $__errorArgs = ['pot_bpjs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('pot_bpjs')); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="text-right">
                        <span id="pot_bpjs_preview">Rp. 0</span>
                    </td>
                </tr>
                <tr>
                    <td>Transportasi</td>
                    <td>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Rp</span>
                            </div>
                            <input type="text" name="transportasi" class="form-control <?php $__errorArgs = ['transportasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="transportasi" value="0" placeholder="0" onkeypress="return hanyaAngka(this)" maxlength="8" autocomplete="off">
                        </div>
                        <?php $__errorArgs = ['transportasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('transportasi')); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                    <td class="text-right">
                        <span id="transportasi_preview">Rp. 0</span>
                    </td>
                </tr>
                </tbody>
                <tr>
                    <td>Apakah Karyawan ini lembur?</td>
                    <td colspan="2">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="lembur" id="lembur" value="true" class="toggle-form-lembur" <?php echo e(old('lembur') ? 'checked' : ''); ?> >
                            <label class="form-check-label" for="lembur">
                                Ya
                            </label>
                        </div>
                    </td>
                </tr>
               
                <tbody id="form-lembur" style="display: none">
                    <tr class="bg-white">
                        <td>Lembur</td>
                        <td colspan="2">
                            <div class="input-group">
                                <input type="text" name="jam_lembur" id="jam_lembur" value="0" class="form-control <?php $__errorArgs = ['jam_lembur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="masukan jumlah lembur.." autocomplete="off" maxlength="2" min="0" onkeypress="return hanyaAngka(this)" disabled>
                                <div class="input-group-append">
                                    <span class="input-group-text">Jam</span>
                                </div>
                            </div>
                            <?php $__errorArgs = ['jam_lembur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                    </tr>
                    <tr style="background-color: rgba(0,0,0,.05)">
                        <td>Gaji Lembur / Jam</td>
                        <td style="min-width: 180px;">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Rp</span>
                                </div>
                                <input type="text" name="gaji_lembur" id="gaji_lembur" value="0" class="form-control <?php $__errorArgs = ['gaji_lembur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="0" autocomplete="off" maxlength="8" disabled>
                            </div>
                            <?php $__errorArgs = ['gaji_lembur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('gaji_lembur')); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </td>
                        <td class="text-right">
                            <span id="gaji_lembur_preview">Rp. 0</span>
                        </td>
                    </tr>
                </tbody>
                    <tr class="font-weight-bold bg-white" style="font-size: 18px;">
                        <td>Total Gaji</td>
                        <td colspan="2" class="text-right">
                            <input type="hidden" name="total" id="grand_total_salary_hidden">
                            <span id="grand_total_salary">Rp. 0</span>
                        </td>
                    </tr>
        </table>
    </div>
      
    </div>
    <div class="card-footer">
        <div class="float-left">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="dibayar" name="status_gaji" value="Lunas" class="toggle-form-dibayar" checked>
                <label class="form-check-label" for="dibayar">
                    Tandai telah di gaji
                </label>
            </div>
        </div>
        <div class="text-right">
            <div class="form-group mb-0">
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary"><i class="fa fa-arrow-left"></i> Back</a>
                <button type="submit" class="btn btn-primary" name="submit"><i class="fas fa-check mr-1"></i> Simpan</button> 
            </div>
        </div>
    </div><?php /**PATH D:\sipg\resources\views/salary/detail/_form.blade.php ENDPATH**/ ?>