
<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.0.6-rc.1/dist/css/select2.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper pb-3">
        <div class="content pb-5 pt-3">
              <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-light">
                                <h3 class="card-title back-top" style="margin-top: 5px;">
                                    <a href="<?php echo e(route('salary.index')); ?>" title="Kembali" data-toggle="tooltip" data-placement="right" class="btn text-muted">
                                        <i class="fa fa-arrow-left fa-fw"></i></span>
                                    </a>
                                </h3>
                                <div class="float-left offset-5 pt-1">
                                    <span class="d-none d-md-block d-lg-block"><?php echo e($title ?? ''); ?></span>
                                </div>
                                <div class="float-right row">
                                    <form action="<?php echo e(url()->current()); ?>">
                                        <div class="input-group">
                                            <select name="filter" class="form-control input-sm select2">
                                                <option value="">Tampilkan semua</option>
                                                <?php if(!empty($filter)): ?>
                                                    <option value="all">SHOW ALL</option>
                                                <?php endif; ?>
                                                <?php $__currentLoopData = $periode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->periode); ?>" <?php echo e($item->periode == old('filter', $filter) ? 'selected':''); ?>><?php echo e(strtoupper($item->periode)); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <div class="input-group-append">
                                                <button type="submit" class="btn btn-secondary btn-sm">Filter</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div> 
                                <table class="table no-border header-table mb-0 ml-2 mt-2">
                                    <tr style="line-height: 1px;">
                                        <td width="100">Nama</td>
                                        <td width="10" class="text-center">:</td>
                                        <td><?php echo e($staff->name); ?></td>
                                    </tr>
                                    <tr style="line-height: 1px;">
                                        <td width="100">Position Status</td>
                                        <td width="10" class="text-center">:</td>
                                        <td><?php echo e($staff->position->status); ?></td>
                                    </tr>
                                    <tr style="line-height: 1px;">
                                        <td>Periode</td>
                                        <td>:</td>
                                        <td><?php echo e(ucwords($filter ?? 'All')); ?></td>
                                    </tr>
                                </table>
                            <div class="table-responsive">
                                <div class="card-body p-3">
                                    <table class="table table-bordered mb-0" style="font-size: 14px;">
                                        <thead>
                                            <tr class="bg-light">
                                                <th>Periode</th>
                                                <th>Salary</th>
                                                <th>Tgl. Salary</th>
                                                <th>Status</th>
                                                <th>Lembur</th>
                                                <th>Gaji Lembur</th>
                                                <?php if($staff->position->status == 'Staff'): ?>
                                                    <th>BPJS</th>
                                                    <th>Transportasi</th>
                                                <?php endif; ?>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr style="line-height: 1;">
                                                    <td><?php echo e(ucwords($item->periode)); ?></td>
                                                    <td>Rp. <?php echo e(number_format($item->salary, 0, ',', '.')); ?></td>
                                                    <td><?php echo e(date('d-m-Y', strtotime($item->tgl_salary))); ?></td>
                                                    <td>
                                                        <span class="badge <?php echo e($item->status_gaji == 'Lunas' ? 'badge-success' : 'badge-danger'); ?>"><?php echo e($item->status_gaji ?? 'Belum Lunas'); ?></span>
                                                    </td>
                                                    <td><?php echo e($item->jumlah_overtime); ?></td>
                                                    <td>Rp. <?php echo e(number_format($item->uang_overtime, 0, ',', '.')); ?> / Jam</td>
                                                    <?php if($staff->position->status == 'Staff'): ?>
                                                    <td>Rp. <?php echo e(number_format($item->pot_bpjs, 0, ',', '.')); ?></td>
                                                    <td>Rp. <?php echo e(number_format($item->transportasi, 0, ',', '.')); ?></td>
                                                    <?php endif; ?>
                                                    <td class="font-weight-bold">Rp. <?php echo e(number_format($item->total, 0, ',', '.')); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td class="text-center" colspan="9">Tidak ada data untuk ditampilkan</td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="card-footer">
                                <div class="text-right">
                                    <?php if(!empty($filter)): ?>
                                        <a href="<?php echo e(route('salary.export.excel', [$staff->id, $filter])); ?>" class="btn btn-success btn-sm" id="export-excel">
                                            <i class="fa fa-file-excel-o fa-fw"></i> Export Excel
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('salary.export.excel', [$staff->id, 'all'])); ?>" class="btn btn-success btn-sm" id="export-excel">
                                            <i class="fa fa-file-excel-o fa-fw"></i> Export Excel
                                        </a>
                                    <?php endif; ?>
                                </div><br>
                                <div class="text-right">
                                    <?php if(!empty($filter)): ?>
                                        <a href="<?php echo e(route('salary.export.cetak_pdf', [$staff->id, $filter])); ?>" class="btn btn-danger btn-sm" id="cetak_pdf">
                                            <i class="fa fa-file-pdf-o fa-fw"></i> Export pdf
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('salary.export.cetak_pdf', [$staff->id, 'all'])); ?>" class="btn btn-danger btn-sm" id="cetak_pdf">
                                            <i class="fa fa-file-pdf-o fa-fw"></i> Export pdf
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div id="loading"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.6-rc.1/dist/js/select2.min.js"></script>
<?php echo $__env->make('alert.mk-notif', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $('.select2').select2({
			placeholder : 'Periode..'
        });
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();
        });

        $('#export-excel').on("click", function () {
            $(this).addClass('disabled');
            setTimeout(RemoveClass, 1000);
        });

        function RemoveClass() {
            $('#export-excel').removeClass("disabled");
		}
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipg\resources\views/salary/show.blade.php ENDPATH**/ ?>