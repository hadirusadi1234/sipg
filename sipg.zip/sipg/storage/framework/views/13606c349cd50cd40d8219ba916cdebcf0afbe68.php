<?php
    header ("Cache-Control: no-cache, must-revalidate");
    header ("Pragma: no-cache");
    header ("Content-type: application/x-msexcel");
    header ("Content-type: application/octet-stream");
    header ("Content-Disposition: attachment; filename=Laporan-absensi-departement-".strtolower($filter)."-periode-".ucwords($absensi->periode).".xls");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Apurav - Report</title>
    <style>
        #master td{
            vertical-align: middle;
            
        }
    </style>
</head>
<body>
    <div style="text-align: center; font-size: 20px;">
        <b><u>DAFTAR ABSENSI</u></b>
    </div>         
    
    <br>
    <table style="">
        <tr>
            <td colspan="2" style="width: 100px;">Periode</td>
            <td colspan="5">: <?php echo e(str_replace('-', ' - ', ucwords($absensi->periode))); ?></td>
        </tr>
        <tr>
            <td colspan="2" style="width: 100px;">Departement</td>
            <td colspan="5" style="text-align: left">: <?php echo e(ucwords($filter)); ?></td>
        </tr>
    </table>
    <br>
    
    <table border="1" style="font-size: 14px;width: 100%;">
        <tbody>
            <tr style="font-weight: bold;line-height: 2;text-align: center;background-color: #18c33e;">
                <td colspan="3" style="vertical-align : middle;width: 10px;">KEAHLIAN</td>
                <?php if(count($attendance_date) > 0): ?>
                    <td colspan="<?php echo e(count($attendance_date)); ?>" style="vertical-align : middle;white-space:normal;
                    width: auto;
                    height: auto;
                    word-wrap: break-word;">TANGGAL ABSEN</td>
                <?php endif; ?>
                <td rowspan="2" style="vertical-align : middle;">Total Kehadiran</td>
            </tr>
            
            <tr style="line-height: 2;text-align: center;background-color: #dee2e6;">
                <td style="width:5px;height: 20px;">No.</td>
                <td>Nama</td>
                <td>Posisi</td>
                
                
                <?php $__currentLoopData = $attendance_date; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td style="min-width:50px; vertical-align: middle; text-align: center; background-color: yellow" ><?php echo e(date('d', strtotime($d->tanggal_absen))); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
            </tr>
                <?php
                    $grand_total = 0;
                ?>

                <?php $__empty_1 = true; $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr style="text-align: left;" id="master">
                    <td style="text-align: center"><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($schedule->staff->name); ?></td>
                    <td><?php echo e($schedule->staff->position->name); ?></td>
                    
                    <?php
                        $sum_kehadiran = 0;
                        $sum_jam = 0;
                        $grand_hari = 0;
                        $grand_lembur = 0;
                        $count_absen_staff = $schedule->absensi->where('periode', $absensi->periode)->count();
                    ?>
                    <?php $__empty_2 = true; $__currentLoopData = $schedule->absensi->where('periode', $absensi->periode); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <?php if($loop->first): ?>
                            <?php if(count($attendance_date) != $count_absen_staff): ?>
                                <td style="vertical-align: middle; background-color: #ccc" colspan="<?php echo e(intval(count($attendance_date)) - intval($count_absen_staff)); ?>"></td>
                            <?php endif; ?> 
                        <?php endif; ?>

                        <?php if($item->attendance_id != ''): ?>     
                            <td style="color: white; text-align: center; background-color: <?php echo e($item->attendance->color); ?>">
                                <?php echo e($item->attendance->singkatan); ?>

                            </td>
                        <?php else: ?>
                            <td style="width:20px;text-align: center;"><i style="line-height: 0.2;"></i></td>
                        <?php endif; ?>
                    
                        <?php
                            $sum_jam += $item->jumlah_lembur;
                            $sum_kehadiran +=  $item->attendance->value;
                            $grand_hari = $sum_kehadiran * $schedule->schedule;
                            $grand_lembur = $sum_jam * $schedule->uang_overtime;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                    <?php endif; ?>

                    <?php
                        $total = $grand_hari + $grand_lembur;
                        $grand_total += $total;
                    ?>
                    <td style="vertical-align: middle; text-align: center;"><?php echo e($sum_kehadiran); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <td style="text-align: center;" colspan="<?php echo e(3 + count($attendance_date) + 7); ?>">Tidak ada data</td>
                <?php endif; ?>
        </tbody>
    </table>       
</body>
</html><?php /**PATH D:\sipg\resources\views/absensi/detail/excel.blade.php ENDPATH**/ ?>