

<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset ('css/sweetalert.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper pb-3">
        <div class="content-header">
            <div class="container-fluid">
                <form>
                    <div class="form-inline">
                        <div class="input-group app-shadow">
                            <div class="input-group-append">
                                <div class="input-group-text bg-white border-0">
                                    <span><i class="fa fa-search"></i> </span>
                                </div>
                            </div>
                            <input type="search" placeholder="Search" aria-label="Search..." class="form-control input-flat border-0" id="search"> 
                        </div> 
                        <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-default app-shadow d-none d-md-inline-block ml-auto">
                            <i class="fas fa-user-plus fa-fw"></i> Tambah
                        </a>
                    </div>
                </form>
            </div>
        </div>
    
        <div class="content pb-5">
              <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-light">
                                Data Roles
                                <span class="badge badge-danger float-right float-xl-right mt-1"><?php echo e($count); ?></span>
                            </div>
                            <table id="datatable" class="table table-hover table-striped ">
                                <thead class="bg-white">
                                    <tr>
                                        <th style="min-width:50px;"></th> 
                                        <th>Name</th> 
                                        <th>Display Name</th>
                                    </tr>
                                </thead> 
                                <tbody>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="hide<?php echo e($item->id); ?>">
                                            <td class="text-left">
                                                <a href="#" class="text-secondary nav-link p-0" title="Lihat opsi" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                                <div class="dropdown-menu text-center">
                                                    <a href="<?php echo e(route('roles.edit', $item->id)); ?>" class="text-secondary mx-2" data-toggle="tooltip" title="Edit"><i class="fa fa-edit"></i></a> 
                                                    <a href="javascript:void(0)" onClick="hapus(<?php echo e($item->id); ?>)" class="text-secondary ml-2" data-toggle="tooltip" title="Hapus"><i class="fa fa-trash"></i></a>
                                                </div>
                                            </td>
                                            <td><?php echo e($item->name); ?></td> 
                                            <td ><?php echo e($item->display_name); ?></td> 
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-lg rounded-circle btn-primary btn-fly d-block d-md-none app-shadow">
        <span><i class="fas fa-plus fa-sm align-middle"></i></span>
    </a>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo e(asset('js/sweetalert.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sweetalert-dev.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatables.js')); ?>"></script>
    <script>
        function hapus(id){
            swal({
            title: 'Yakin.. ?',
            text: "Data anda akan dihapus. Tekan tombol yes untuk melanjutkan.",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes!',
            closeOnConfirm: false,
            closeOnCancel: false
            },
            function(isConfirm){
                if (isConfirm) {
                    $.ajax({
                        url:"<?php echo e(URL::to('/roles/destroy')); ?>",
                        data:"id=" + id ,
                        success: function(html)
                        {
                            swal("Deleted", "Data Berhasil Di Hapus.", "success");
                            $("#hide"+id).hide(300);   
                        }
                    });
                    
                }else{
                    swal("Canceled", "Anda Membatalkan! :)","error");
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sipg\resources\views/roles/index.blade.php ENDPATH**/ ?>