<div class="card-body">
        
    <?php if($staff ?? ''): ?>
        <div class="alert alert-warning text-justify">
            <strong>Warning !!</strong> Data staff belum ada, anda tidak dapat melakukan absensi. Silahkan input data staff terlebih dulu 
            <a class="float-right" href="<?php echo e(route('staff.create')); ?>" data-toggle="tooltip" title="Silahkan klik untuk menginput data pekerja" style="text-decoration-color: blue;">
                <span class="text-primary">Input Sekarang ?</span>  
            </a>
        </div>
    <?php else: ?>
        <div class="card card-solid">
            <div class="card-body pb-0 pt-3">
                <blockquote>
                    <b>Keterangan!!</b><br>
                    <small><cite title="Source Title">Inputan Yang Ditanda Bintang Merah (<span class="text-danger">*</span>) Harus Di Isi !!</cite></small>
                </blockquote>
            </div>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card-header with-border pl-0 pb-1">
                <span class="col-form-label text-bold">Daftar Absen</span>
            </div>
            <br>
            <div class="table-responsive">
                <table class='table table-striped' id="AbsensiID">
                    <thead>
                        <tr class="bg-light">
                            <td class="text-center">#</td>
                            <td>Staff</td>
                            <td>Status</td>
                            <td>Tgl. Masuk</td>
                            <td>Ket. Schedule</td>
                            <td class="text-center" style="min-width: 150px;">Attendance</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <input type="hidden" name="schedule_id[]" class="form-control " value="<?php echo e($item->id); ?>" readonly required>
                                <input type="hidden" name="staff_name[]" class="form-control" value="<?php echo e($item->staff->name); ?>" readonly required>
                                <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <?php echo e($item->staff->name); ?>

                                </td>
                                <td>
                                    <span class="badge <?php echo e($item->staff->position->status == 'Staff' ? 'badge-info' : 'badge-secondary'); ?>"><?php echo e($item->staff->position->status); ?></span>
                                </td>
                                <td><?php echo e(date('d-m-Y', strtotime($item->tgl_masuk))); ?></td>
                                <td><?php echo e($item->ket_schedule); ?></td>
                                <td>
                                    <div class="float-right">
                                        <select name="attendance[]" class="form-control select2<?php echo e($errors->has('attendance') ? ' is-invalid' : ''); ?>" required>
                                            <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>" ><?php echo e(strtoupper($item->name)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('attendance')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('attendance')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    </div>
    <div class="card-footer">
        <div class="text-right">
            <div class="form-group mb-0">
                <button type="reset" class="btn btn-secondary"><i class="fas fa-undo mr-1"></i> Reset</button>
                <button type="submit" class="btn btn-primary" name="btn_absen" <?php echo e($info ?? ''); ?>><i class="fas fa-check-double mr-1"></i> Simpan</button> 
            </div>
        </div>
    </div><?php /**PATH D:\sipg\resources\views/absensi/detail/_form.blade.php ENDPATH**/ ?>