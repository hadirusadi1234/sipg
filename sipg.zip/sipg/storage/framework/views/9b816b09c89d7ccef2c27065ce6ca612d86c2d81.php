<?php if(Session::has('alert-type')): ?>
    <script>
        mkNotifications();
        // var options = 
        // {
        //     link: {
        //       function: function() 
        //       {
        //           mkNoti('Link Callback function','This is the callback function.', { status: 'success' });
        //       }
        //     },
        //     dismissable: false,
        //     callback: function() 
        //     {
        //         mkNoti('Close Callback function','This is the callback function.', { status: 'success' });
        //     },
        //     sound: true
        // };

        var type = "<?php echo e(Session::get('alert-type', 'info')); ?>";
        switch(type){
            case 'info':
                mkNoti("<?php echo e(Session::get('message')); ?>",
                        {
                            sound : true,
                            status: "info",
                            link: {
                              url: "http://www.adi-techno.com/",
                              target: "_blank",
                            }
                        }
                    );
                break;

            case 'warning':
                mkNoti(
                    "Warning",
                    "<?php echo Session::get('message'); ?>",
                        {
                            sound : true,
                            status: "warning"
                        }
                    );
                break;

            case 'success':
                mkNoti(
                        "Success",
                        "<?php echo e(Session::get('message')); ?>", 
                        {
                            sound : true,
                            status: "success"
                        }
                    );
                break;

            case 'error':
                mkNoti(
                        "Rejected",
                        "<?php echo e(Session::get('message')); ?>", 
                        {
                            sound : true,
                            status: "danger",
                        }
                    );
                break;
        }
    </script>
<?php endif; ?><?php /**PATH D:\sipg\resources\views/alert/mk-notif.blade.php ENDPATH**/ ?>